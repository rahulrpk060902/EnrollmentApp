/**
 * 
 */
/**
 * 
 */
module interview {
	requires java.desktop;
	requires java.sql;
}