package comm;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;

public class EnrollmentApp extends JFrame {

    JComboBox<String> studentCombo;
    JComboBox<String> courseCombo;
    JButton enrollButton;

    JTable reportTable;
    DefaultTableModel reportModel;

    Connection con;
    DefaultComboBoxModel<String> studentModel = new DefaultComboBoxModel<>();
    DefaultComboBoxModel<String> courseModel = new DefaultComboBoxModel<>();

    public EnrollmentApp() {
        setTitle("Student Course Enrollment");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top panel for form
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        studentCombo = new JComboBox<>(studentModel);
        courseCombo = new JComboBox<>(courseModel);
        enrollButton = new JButton("Show report");

        formPanel.add(new JLabel("Select Student:"));
        formPanel.add(studentCombo);
        formPanel.add(new JLabel("Select Course:"));
        formPanel.add(courseCombo);
        formPanel.add(new JLabel(""));
        formPanel.add(enrollButton);

        add(formPanel, BorderLayout.NORTH);

        reportModel = new DefaultTableModel();
        reportModel.setColumnIdentifiers(new String[] {"Enrollment ID", "Student Name", "Course Name", "Date Enrolled"});
        reportTable = new JTable(reportModel);
        add(new JScrollPane(reportTable), BorderLayout.CENTER);

        connect();
        loadStudents();
        loadCourses();
        loadEnrollments();

        enrollButton.addActionListener( e-> enrollStudent());

        setVisible(true);
    }

    void connect() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch1", "root", "123456789");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void loadStudents() {
        try {
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM students");
            studentModel.removeAllElements();
            while (rs.next()) {
                studentModel.addElement(rs.getInt("id") + "-" + rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void loadCourses() {
        try {
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM courses");
            courseModel.removeAllElements();
            while (rs.next()) {
                courseModel.addElement(rs.getInt("id") + "-" + rs.getString("course_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void enrollStudent() {
        try {
            int studentId = Integer.parseInt(studentCombo.getSelectedItem().toString().split("-")[0]);
            int courseId = Integer.parseInt(courseCombo.getSelectedItem().toString().split("-")[0]);

           
            PreparedStatement check = con.prepareStatement(
                "SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?"
            );
            check.setInt(1, studentId);
            check.setInt(2, courseId);
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Student already enrolled in this course!");
                return;
            }

            PreparedStatement pst = con.prepareStatement(
                "INSERT INTO enrollments (student_id, course_id, date_enrolled) VALUES (?, ?, ?)"
            );
            pst.setInt(1, studentId);
            pst.setInt(2, courseId);
            pst.setDate(3, Date.valueOf(LocalDate.now()));

            int inserted = pst.executeUpdate();
            if (inserted > 0) {
                JOptionPane.showMessageDialog(this, "Enrolled successfully!");
                loadEnrollments();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error enrolling student.");
        }
    }

    void loadEnrollments() {
        try {
            reportModel.setRowCount(0); 
            String query = """
                SELECT e.id, s.name, c.course_name, e.date_enrolled
                FROM enrollments e
                JOIN students s ON e.student_id = s.id
                JOIN courses c ON e.course_id = c.id
            """;
            ResultSet rs = con.createStatement().executeQuery(query);
            while (rs.next()) {
                reportModel.addRow(new Object[] {
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("course_name"),
                    rs.getDate("date_enrolled")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new EnrollmentApp();
    }
}